package com.harindra.tvlauncher

import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

object WeatherRepository {

    fun fetchWeatherSummary(): String? {
        return try {
            // Fast IP-based city lat/lon (fallback to New Delhi if blocked)
            var lat = 28.6139
            var lon = 77.2090
            try {
                val geo = httpGet("https://ipapi.co/json/", 2500)
                if (geo.isNotBlank()) {
                    val g = JSONObject(geo)
                    val la = g.optDouble("latitude", Double.NaN)
                    val lo = g.optDouble("longitude", Double.NaN)
                    if (!la.isNaN() && !lo.isNaN()) { lat = la; lon = lo }
                }
            } catch (_: Throwable) { }

            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current_weather=true"
            val raw = httpGet(url, 3500)
            if (raw.isBlank()) return null
            val cw = JSONObject(raw).optJSONObject("current_weather") ?: return null
            val temp = Math.round(cw.optDouble("temperature", 25.0))
            val code = cw.optInt("weathercode", 0)
            val icon = when {
                code == 0 -> "☀"
                code in 1..3 -> "⛅"
                code in 51..67 || code in 80..82 -> "🌧"
                code >= 95 -> "⛈"
                else -> "🌤"
            }
            "$icon ${temp}°C"
        } catch (_: Throwable) {
            null
        }
    }

    private fun httpGet(urlStr: String, timeoutMs: Int): String {
        val conn = (URL(urlStr).openConnection() as HttpURLConnection).apply {
            connectTimeout = timeoutMs
            readTimeout = timeoutMs
            setRequestProperty("User-Agent", "UltraTVPro/14.0")
        }
        return try {
            if (conn.responseCode in 200..299) {
                BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8)).use { it.readText() }
            } else ""
        } finally {
            conn.disconnect()
        }
    }
}
