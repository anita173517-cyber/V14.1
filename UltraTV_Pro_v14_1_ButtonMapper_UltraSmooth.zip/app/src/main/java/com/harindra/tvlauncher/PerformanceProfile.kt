package com.harindra.tvlauncher

import android.app.ActivityManager
import android.content.Context

enum class PerformanceTier(
    val id: Int,
    val label: String,
    val cacheKb: Int,
    val focusScale: Float,
    val animDurationMs: Long,
    val enable3dTilt: Boolean,
    val enableKenBurns: Boolean,
    val enableDynamicBackdrop: Boolean
) {
    ULTRA_LITE(0, "Ultra Lite (512MB RAM)", 2560, 1.04f, 0L, false, false, false),
    LOW_RAM(1, "Low RAM (1GB RAM)", 4096, 1.05f, 0L, false, false, false),
    BALANCED(2, "Balanced (2GB RAM — Fast 60fps)", 8192, 1.06f, 60L, false, false, false),
    CINEMATIC(3, "Cinematic (3GB+ RAM — Full FX)", 14336, 1.09f, 130L, false, true, true);

    companion object {
        @Volatile
        private var cachedTotalRamMb: Long = -1L

        @Volatile
        private var cachedResolved: PerformanceTier? = null

        fun invalidateCache() {
            cachedResolved = null
        }

        fun fromId(id: Int): PerformanceTier = values().firstOrNull { it.id == id } ?: BALANCED

        fun detectForRamMb(totalRamMb: Long): PerformanceTier = when {
            totalRamMb <= 650L -> ULTRA_LITE
            totalRamMb <= 1250L -> LOW_RAM
            totalRamMb <= 2600L -> BALANCED
            else -> CINEMATIC
        }

        fun resolve(context: Context, prefs: PrefsManager): PerformanceTier {
            cachedResolved?.let { return it }
            val result = if (prefs.isUltraLiteMode) {
                ULTRA_LITE
            } else {
                val saved = prefs.performanceTier
                if (saved in 0..3) {
                    fromId(saved)
                } else {
                    if (cachedTotalRamMb <= 0L) {
                        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
                        val mi = ActivityManager.MemoryInfo()
                        am?.getMemoryInfo(mi)
                        cachedTotalRamMb = mi.totalMem / (1024L * 1024L)
                    }
                    detectForRamMb(cachedTotalRamMb)
                }
            }
            cachedResolved = result
            return result
        }
    }
}
