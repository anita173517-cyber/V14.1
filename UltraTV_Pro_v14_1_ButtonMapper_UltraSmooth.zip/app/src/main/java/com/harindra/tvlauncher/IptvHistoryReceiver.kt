package com.harindra.tvlauncher

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class IptvHistoryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action != "com.harindra.tvlauncher.ACTION_SAVE_LAST_CHANNEL") return
        val name = intent.getStringExtra("channel_name")?.trim().orEmpty()
        val url = intent.getStringExtra("stream_url")?.trim().orEmpty()
        if (name.isBlank() || url.isBlank()) return

        val ch = LiveChannel(
            id = "ram_${url.hashCode()}",
            name = name,
            group = intent.getStringExtra("group")?.trim().orEmpty().ifBlank { "RAM PLAYER IPTV" },
            logoUrl = intent.getStringExtra("logo_url")?.trim().orEmpty(),
            streamUrl = url,
            userAgent = intent.getStringExtra("user_agent")?.trim().orEmpty(),
            referrer = intent.getStringExtra("referrer")?.trim().orEmpty()
        )
        PrefsManager(context).recordIptvChannelWatch(ch)
    }
}
