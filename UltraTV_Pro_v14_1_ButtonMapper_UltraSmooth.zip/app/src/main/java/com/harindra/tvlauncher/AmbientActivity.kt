package com.harindra.tvlauncher

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AmbientActivity : AppCompatActivity() {

    private lateinit var tvClock: TextView
    private lateinit var tvDate: TextView
    private lateinit var ivBg: ImageView
    private val handler = Handler(Looper.getMainLooper())
    private val backdrops = intArrayOf(
        R.drawable.hero_scifi_4k,
        R.drawable.hero_fantasy_4k,
        R.drawable.hero_action_4k,
        R.drawable.hero_kids_4k,
        R.drawable.hero_sports_4k
    )
    private var bgIndex = 0

    private val ticker = object : Runnable {
        override fun run() {
            val now = Date()
            val prefs = PrefsManager(this@AmbientActivity)
            val fmt = if (prefs.is24HourClock) "HH:mm" else "h:mm a"
            tvClock.text = SimpleDateFormat(fmt, Locale.getDefault()).format(now)
            tvDate.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)
            handler.postDelayed(this, 10_000L)
        }
    }

    private val bgSwapper = object : Runnable {
        override fun run() {
            bgIndex = (bgIndex + 1) % backdrops.size
            ivBg.setImageResource(backdrops[bgIndex])
            Animation4D.animateKenBurnsHero(ivBg, true)
            handler.postDelayed(this, 18_000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ambient)
        tvClock = findViewById(R.id.tvAmbientClock)
        tvDate = findViewById(R.id.tvAmbientDate)
        ivBg = findViewById(R.id.ivAmbientBg)
        findViewById<View>(R.id.ambientRoot).setOnClickListener { finish() }
        handler.post(ticker)
        handler.postDelayed(bgSwapper, 18_000L)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacksAndMessages(null)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        finish()
        return true
    }
}
